Austin Harris, ash170000
Ethan Cooper, ewc18001

Edit launcher.sh to add the correct environment variables
run launcher.sh from same directory as the java files:
./launcher.sh

it will automatically compile and run everything

edit cleanup.sh with the environment variables:
./cleanup.sh

it will terminate all the running programs