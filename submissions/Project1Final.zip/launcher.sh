#!/bin/bash

# Change this to your netid
export netid=$(whoami)

# Root directory of your project
export PROJDIR=$HOME/cs6378/proj1/

# Directory where the config file is located on your local system
export CONFIGLOCAL=./config.txt

# Directory your java classes are in
export BINDIR=$PROJDIR

# Your main project class
export PROG=Node

# Directory to place log files
# ends with a slash
export OUTPUTDIR=$PROJDIR/

javac Node.java Launcher.java
java Launcher