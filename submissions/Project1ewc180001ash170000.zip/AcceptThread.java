/*
 * Ethan Cooper
 * ewc180001
 * CS 6378.001
 */
import com.sun.nio.sctp.*;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;

public class AcceptThread extends Thread {
    private final Node ownNode;
    private final int portNum;
    private boolean acceptNew;

    public AcceptThread(Node ownNode, int portNum) {
        this.ownNode = ownNode;
        this.portNum = portNum;
        this.acceptNew = true;
    }

    public void run() {
        try {
            InetSocketAddress addr = new InetSocketAddress(portNum); // Get address from port number
            SctpServerChannel ssc = SctpServerChannel.open(); //Open server channel
            ssc.bind(addr);//Bind server channel to address
            while (acceptNew) {
                SctpChannel sc = ssc.accept();
                // Should get a message immediately from client with the nodeNum of the remote device
                ByteBuffer buf = ByteBuffer.allocateDirect(Node.MAX_MSG_SIZE);
                sc.receive(buf, null, null); // Messages are received over SCTP using ByteBuffer
                String msg = Message.fromByteBuffer(buf).message;
                System.out.println("Message received from node: " + msg);

                // parse int from the message
                int connectedNodeNum = Integer.parseInt(msg);
                ListenerThread lt = new ListenerThread(ownNode, sc, connectedNodeNum);
                lt.start();
                ownNode.addChannel(connectedNodeNum, sc);
                if (ownNode.getAllConnectionsEstablished()) {
                    acceptNew = false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }

    }
}